"""
Authentication routes (simplified single-admin)

Uses HTTP Basic authentication only. No JWT/tokens - frontend stores
credentials in sessionStorage and sends Basic header on each request.
"""
import secrets

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel

from app.core.config import settings

router = APIRouter()
security = HTTPBasic()


class UserInfo(BaseModel):
    username: str
    role: str = "admin"


def verify_credentials(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    """Verify admin credentials using constant-time comparison"""
    correct_username = secrets.compare_digest(
        credentials.username.encode("utf-8"),
        settings.ADMIN_USERNAME.encode("utf-8")
    )
    correct_password = secrets.compare_digest(
        credentials.password.encode("utf-8"),
        settings.ADMIN_PASSWORD.encode("utf-8")
    )
    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=401,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username


# Dependency to protect routes - use this in router dependencies
require_admin = Depends(verify_credentials)


@router.get("/me", response_model=UserInfo)
async def get_current_user(username: str = Depends(verify_credentials)):
    """Get current user info (also serves as login verification)"""
    return UserInfo(username=username, role="admin")

