"""
OpenAI Translation Adapter
Handles multilingual translation with glossary support
"""
import json
from datetime import datetime
from typing import List, Optional, Dict, Any

import httpx
from openai import AsyncOpenAI

from app.core.config import settings


class TranslateAdapter:
    """Adapter for OpenAI-based translation with glossary"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        timeout_sec: Optional[int] = None,
    ):
        self.api_key = api_key or settings.OPENAI_API_KEY
        self.model = model or settings.TRANSLATION_MODEL
        self.timeout_sec = timeout_sec or settings.TRANSLATE_HTTP_TIMEOUT_SEC
        
        # Configure client with timeout
        self.client = AsyncOpenAI(
            api_key=self.api_key,
            timeout=httpx.Timeout(self.timeout_sec, connect=10.0),
        )
    
    async def translate(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        do_not_translate: Optional[List[str]] = None,
        preferred_translations: Optional[List[Dict[str, str]]] = None,
        style: str = "formal",
        extra_rules: Optional[str] = None,
    ) -> tuple[str, Dict[str, Any]]:
        """
        Translate text with glossary support.
        
        Args:
            text: Source text to translate
            source_lang: Source language code (e.g., 'en')
            target_lang: Target language code (e.g., 'ru')
            do_not_translate: Terms to keep in original language
            preferred_translations: [{term, lang, translation}, ...]
            style: Translation style ('formal', 'neutral', 'friendly')
            extra_rules: Additional translation instructions
            
        Returns:
            Tuple of (translated_text, metadata)
        """
        do_not_translate = do_not_translate or []
        preferred_translations = preferred_translations or []
        
        # Filter preferred translations for target language
        lang_translations = [
            pt for pt in preferred_translations 
            if pt.get("lang") == target_lang
        ]
        
        # Build prompt
        system_prompt = self._build_system_prompt(
            source_lang,
            target_lang,
            do_not_translate,
            lang_translations,
            style,
            extra_rules
        )
        
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ],
            temperature=0.3,  # Lower temperature for consistent translations
        )
        
        translated_text = response.choices[0].message.content.strip()
        
        # Build metadata
        metadata = {
            "model": self.model,
            "source_lang": source_lang,
            "target_lang": target_lang,
            "style": style,
            "timestamp": datetime.utcnow().isoformat(),
            "glossary_terms_count": len(do_not_translate) + len(lang_translations),
            "source_checksum": self._checksum(text),
        }
        
        return translated_text, metadata
    
    async def translate_batch(
        self,
        texts: List[str],
        source_lang: str,
        target_lang: str,
        do_not_translate: Optional[List[str]] = None,
        preferred_translations: Optional[List[Dict[str, str]]] = None,
        style: str = "formal",
        extra_rules: Optional[str] = None,
    ) -> List[tuple[str, Dict[str, Any]]]:
        """
        Translate multiple texts.
        
        For efficiency, sends all texts in one prompt with numbered format.
        """
        if not texts:
            return []
        
        # For single text, use regular translate
        if len(texts) == 1:
            result = await self.translate(
                texts[0], source_lang, target_lang,
                do_not_translate, preferred_translations, style, extra_rules
            )
            return [result]
        
        do_not_translate = do_not_translate or []
        preferred_translations = preferred_translations or []
        
        lang_translations = [
            pt for pt in preferred_translations 
            if pt.get("lang") == target_lang
        ]
        
        system_prompt = self._build_batch_system_prompt(
            source_lang,
            target_lang,
            do_not_translate,
            lang_translations,
            style,
            extra_rules
        )
        
        # Format input as numbered list
        numbered_input = "\n\n".join(
            f"[{i+1}]\n{text}" for i, text in enumerate(texts)
        )
        
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": numbered_input}
            ],
            temperature=0.3,
        )
        
        # Parse numbered output
        output = response.choices[0].message.content.strip()
        translations = self._parse_numbered_output(output, len(texts))
        
        # Build results with metadata
        results = []
        base_metadata = {
            "model": self.model,
            "source_lang": source_lang,
            "target_lang": target_lang,
            "style": style,
            "timestamp": datetime.utcnow().isoformat(),
            "glossary_terms_count": len(do_not_translate) + len(lang_translations),
            "batch_size": len(texts),
        }
        
        for i, (original, translated) in enumerate(zip(texts, translations)):
            metadata = {
                **base_metadata,
                "batch_index": i,
                "source_checksum": self._checksum(original),
            }
            results.append((translated, metadata))
        
        return results
    
    def _build_system_prompt(
        self,
        source_lang: str,
        target_lang: str,
        do_not_translate: List[str],
        preferred_translations: List[Dict[str, str]],
        style: str,
        extra_rules: Optional[str],
    ) -> str:
        """Build system prompt for translation"""
        
        style_guide = {
            "formal": "Use formal, professional language appropriate for business presentations.",
            "neutral": "Use neutral, clear language.",
            "friendly": "Use friendly, conversational language while maintaining professionalism.",
        }
        
        prompt_parts = [
            f"You are a professional translator from {source_lang} to {target_lang}.",
            f"Style: {style_guide.get(style, style_guide['formal'])}",
            "",
            "IMPORTANT RULES:",
            "1. Preserve ALL numbers, percentages, and numerical values exactly as they appear",
            "2. Preserve ALL ticker symbols, stock codes, and financial abbreviations",
            "3. Preserve ALL acronyms and technical abbreviations (IFRS, ESG, KPI, etc.)",
            "4. Do NOT add, remove, or modify any information - translate only what is given",
            "5. Maintain the same paragraph structure and line breaks",
            "6. Adapt punctuation and formatting to target language conventions where appropriate",
        ]
        
        if do_not_translate:
            prompt_parts.extend([
                "",
                "DO NOT TRANSLATE these terms (keep in original language):",
                ", ".join(do_not_translate)
            ])
        
        if preferred_translations:
            prompt_parts.extend([
                "",
                "USE THESE PREFERRED TRANSLATIONS:"
            ])
            for pt in preferred_translations:
                prompt_parts.append(f"- \"{pt['term']}\" → \"{pt['translation']}\"")
        
        if extra_rules:
            prompt_parts.extend([
                "",
                "ADDITIONAL RULES:",
                extra_rules
            ])
        
        prompt_parts.extend([
            "",
            "Translate the following text. Output ONLY the translation, nothing else."
        ])
        
        return "\n".join(prompt_parts)
    
    def _build_batch_system_prompt(
        self,
        source_lang: str,
        target_lang: str,
        do_not_translate: List[str],
        preferred_translations: List[Dict[str, str]],
        style: str,
        extra_rules: Optional[str],
    ) -> str:
        """Build system prompt for batch translation"""
        
        base_prompt = self._build_system_prompt(
            source_lang, target_lang, do_not_translate,
            preferred_translations, style, extra_rules
        )
        
        batch_instructions = """

INPUT FORMAT:
You will receive multiple texts, each prefixed with [N] where N is the number.

OUTPUT FORMAT:
Translate each text and output in the same numbered format:
[1]
<translation 1>

[2]
<translation 2>

etc.

IMPORTANT: Maintain the exact same numbering. Output exactly the same number of translations as inputs."""

        return base_prompt + batch_instructions
    
    def _parse_numbered_output(self, output: str, expected_count: int) -> List[str]:
        """Parse numbered translation output"""
        import re
        
        # Split by [N] markers
        pattern = r'\[(\d+)\]\s*'
        parts = re.split(pattern, output)
        
        # parts will be: ['', '1', 'translation1', '2', 'translation2', ...]
        translations = {}
        for i in range(1, len(parts) - 1, 2):
            idx = int(parts[i])
            text = parts[i + 1].strip()
            translations[idx] = text
        
        # Build result list in order
        result = []
        for i in range(1, expected_count + 1):
            result.append(translations.get(i, ""))
        
        return result
    
    def _checksum(self, text: str) -> str:
        """Compute checksum of text for tracking"""
        import hashlib
        return hashlib.md5(text.encode()).hexdigest()[:12]


# Singleton instance
translate_adapter = TranslateAdapter()

