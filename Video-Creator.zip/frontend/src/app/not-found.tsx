"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { isAuthenticated } from "@/lib/api";

export default function NotFound() {
  const router = useRouter();

  useEffect(() => {
    // If not authenticated, go to login
    // If authenticated, go to home
    if (isAuthenticated()) {
      router.replace("/");
    } else {
      router.replace("/login");
    }
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="text-slate-400 text-lg">Redirecting...</div>
    </div>
  );
}

